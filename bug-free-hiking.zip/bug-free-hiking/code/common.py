"""여러 단계에서 같이 쓰는 함수와 기준값."""
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
PROCESSED = DATA / "processed"
RESULTS = ROOT / "results"

CLASSES = ["곤충강", "거미강", "지네강", "노래기강", "갑각강"]
TOTAL = "전체(분석 대상)"

# 산과 조사지를 잇는 기준
RADIUS_KM = 30          # 1단계 반경
RADIUS_WIDE_KM = 50     # 2·3단계 반경
BELOW_M = 150           # 코스 최저점보다 이만큼 아래까지
ABOVE_M = 100           # 정상보다 이만큼 위까지
MIN_SITES = 3           # 산 하나에 최소 조사지 수
MAX_MEAN_DIST_KM = 50   # 평균 거리가 이보다 멀면 판단 불가(섬)

PROVINCE_FIX = {"충청북도": "충북", "충청남도": "충남", "전라북도": "전북", "전라남도": "전남",
                "경상북도": "경북", "경상남도": "경남", "강원도": "강원", "경기도": "경기"}
PROVINCE_RE = r"^(경기|강원|충북|충남|전북|전남|경북|경남|인천|울산|" + "|".join(PROVINCE_FIX) + ")"


def dms_to_deg(text):
    """'37 37 36.7' 같은 도·분·초 글자를 소수점 도로 바꾼다."""
    parts = [float(x) for x in re.split(r"\s+", str(text).strip()) if x]
    while len(parts) < 3:
        parts.append(0.0)
    return parts[0] + parts[1] / 60 + parts[2] / 3600


def province(name):
    """조사지명 앞부분에서 도 이름을 뽑는다(없으면 None)."""
    m = re.match(PROVINCE_RE, str(name))
    return PROVINCE_FIX.get(m.group(1), m.group(1)) if m else None


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp, dl = p2 - p1, np.radians(lon2 - lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * r * np.arcsin(np.sqrt(a))


def pct_rank(value, population):
    """population 중 value보다 적은 곳의 비율(%). 같은 값은 절반만 센다."""
    pop = np.asarray(population)
    return 100.0 * ((pop < value).sum() + 0.5 * (pop == value).sum()) / len(pop)


def batch_percentiles(sites, col):
    """조사지마다 같은 조사 묶음 안에서의 백분위(묶음 간 기록 방식 차이를 없애기 위해)."""
    out = pd.Series(index=sites.index, dtype=float)
    for _, g in sites.groupby("조사묶음"):
        vals = g[col].values
        out.loc[g.index] = [pct_rank(v, vals) for v in vals]
    return out


def pick_sites(mt, sites, r1=RADIUS_KM, r2=RADIUS_WIDE_KM, below=BELOW_M, above=ABOVE_M, k=MIN_SITES):
    """산 하나(mt)에 쓸 조사지를 고른다. 조건을 단계적으로 넓힌다."""
    d = haversine_km(mt.최고점_위도, mt.최고점_경도, sites.위도.values, sites.경도.values)
    if pd.isna(mt.최고점_고도m):  # GPX에 고도가 없는 산(대암산)
        band = pd.Series(True, index=sites.index)
    else:
        band = (sites.해발고도m >= mt.코스_최저고도m - below) & (sites.해발고도m <= mt.최고점_고도m + above)
    for radius, use_band, label in [(r1, True, f"{r1}km·높이 맞음"), (r2, True, f"{r2}km·높이 맞음"),
                                    (r2, False, f"{r2}km·높이 무시")]:
        mask = (d <= radius) & (band if use_band else True)
        if mask.sum() >= k:
            return sites[mask].assign(거리km=d[mask]), label
    idx = np.argsort(d)[:k]
    return sites.iloc[idx].assign(거리km=d[idx]), f"가장 가까운 {k}곳"
