"""3단계: 조사지 좌표를 바꾸고, 벌레 기록을 생물 분류(강·목) 기준으로 정리한다.

정리 원칙
1. 목 이름의 오타·표기 차이를 고친다(노린제→노린재, 둥각→등각, 바퀴벌레→바퀴 등).
2. 강은 목을 기준으로 다시 맞춘다(예: '곤충' 강에 적힌 거미목 → 거미강).
3. 측정 방법(땅에 묻은 컵) 때문에 아래 목은 분석에서 뺀다.
   - 톡토기목, 응애목: 몸길이가 대부분 1~2mm 이하라 사람 눈에 거의 띄지 않음
   - 파리목: 날아다니는 무리라 바닥 컵에 든 수로는 실제 수를 대표하기 어려움
4. 낙엽·관목·초본 피복도가 모두 0인 조사지는 피복도를 기록하지 않은 조사 묶음(B)으로 표시한다.
   같은 도 안에서도 이 묶음의 벌레 수가 뚜렷이 적어, 조사 방식이 다른 묶음으로 판단했다.

입력: data/sites_raw.csv, data/records_raw.csv
출력: data/processed/sites_with_bugs.csv, data/processed/records_tidy.csv
"""
import pandas as pd

from common import CLASSES, DATA, PROCESSED, TOTAL, dms_to_deg, province

FIX_ORDER = {"노린제": "노린재", "둥각": "등각", "돌지에": "돌지네", "바퀴벌레": "바퀴",
             "풋잠자리": "풀잠자리", "더듬이벌레": "다듬이벌레", "땅지": "땅지네",
             "그리마지네": "그리마", "애벌레": "유충"}
UNKNOWN_ORDER = {"노", "닥", "웅", "돌", "기타", "곤충", "없음", "(없음)"}  # 잘리거나 알 수 없는 목 이름

ORDER_TO_CLASS = {
    "거미강": ["거미", "장님거미", "응애", "앉은뱅이"],
    "갑각강": ["등각", "단각"],
    "지네강": ["그리마", "돌지네", "왕지네", "땅지네", "돌좀지네"],
    "노래기강": ["각시노래기", "곰보노래기", "띠노래기", "땅노래기"],
    "곤충강": ["딱정벌레", "벌", "개미", "파리", "톡토기", "메뚜기", "바퀴", "노린재", "매미",
             "진딧물", "깍지벌레", "나비", "돌좀", "다듬이벌레", "집게벌레", "대벌레", "땅강아지",
             "밑들이", "사마귀", "잠자리", "풀잠자리", "하루살이", "날도래", "흰개미", "총채벌레", "유충"],
}
O2C = {o: c for c, orders in ORDER_TO_CLASS.items() for o in orders}
RAW_CLASS = {"곤충": "곤충강", "거미": "거미강", "갑각": "갑각강", "지네": "지네강", "지": "지네강",
             "노래기": "노래기강", "노래미": "노래기강"}
EXCLUDE_ORDERS = {"톡토기", "응애", "파리"}

SITE_COLUMNS = {
    "nwSrznNo": "조사지번호", "exmnnNmplc": "조사지명", "haslvVal": "해발고도m",
    "avrgTmprt": "평균기온", "topTmprt": "최고기온", "lowstTmprt": "최저기온",
    "srznPrcptQntt": "강수량", "srznSlrdnQntt": "일사량", "srznGrdnt": "경사",
    "srznDrctnAgl": "방위", "bsrokCvdgr": "암반피복도", "fllvsCvdgr": "낙엽피복도",
    "shrubCvdgr": "관목피복도", "cvdgrHerbRt": "초본피복도", "ddtrCvdgr": "고사목피복도",
    "vgttnNdx": "식생지수", "wamtNdx": "온량지수", "cdnsNdx": "한랭지수"}


def tidy_records(rec):
    order = rec.ordNm.fillna("(없음)").replace(FIX_ORDER)
    order = order.where(~order.isin(UNKNOWN_ORDER), "목 미상")
    cls = order.map(O2C).fillna(rec.clssNm.map(RAW_CLASS))  # 목 미상은 원자료 강을 따른다
    out = pd.DataFrame({"조사지번호": rec.nwSrznNo, "강_원자료": rec.clssNm, "목_원자료": rec.ordNm,
                        "과": rec.famlNm, "강": cls, "목": order, "개체수": rec.totPplti})
    out["분석포함"] = out.강.notna() & ~out.목.isin(EXCLUDE_ORDERS)
    return out


def main():
    sites = pd.read_csv(DATA / "sites_raw.csv", dtype={"nwSrznNo": str})
    sites["위도"] = sites.lttdVal.map(dms_to_deg)
    sites["경도"] = sites.lngtdVal.map(dms_to_deg)
    sites = sites.rename(columns=SITE_COLUMNS)
    sites["도"] = sites.조사지명.map(province)

    rec = tidy_records(pd.read_csv(DATA / "records_raw.csv", dtype={"nwSrznNo": str}))
    used = rec[rec.분석포함]
    by_class = used.pivot_table(index="조사지번호", columns="강", values="개체수", aggfunc="sum", fill_value=0)
    by_class = by_class.reindex(columns=CLASSES, fill_value=0)
    by_class[TOTAL] = by_class[CLASSES].sum(axis=1)
    by_order = used.pivot_table(index="조사지번호", columns="목", values="개체수", aggfunc="sum", fill_value=0)
    by_order.columns = [f"목:{c}" for c in by_order.columns]
    recorded = rec.groupby("조사지번호").size().index
    wide = by_class.join(by_order).reindex(recorded, fill_value=0)

    out = sites.merge(wide.reset_index(), on="조사지번호", how="left")
    out["벌레기록있음"] = out.조사지번호.isin(recorded)
    cover = out[["낙엽피복도", "관목피복도", "초본피복도"]].sum(axis=1)
    out["조사묶음"] = cover.map(lambda v: "B(피복도 기록 없음)" if v == 0 else "A(피복도 기록 있음)")

    PROCESSED.mkdir(parents=True, exist_ok=True)
    out.to_csv(PROCESSED / "sites_with_bugs.csv", index=False, encoding="utf-8-sig")
    rec.to_csv(PROCESSED / "records_tidy.csv", index=False, encoding="utf-8-sig")

    fixed_class = (rec.강.notna() & (rec.강 != rec.강_원자료.map(RAW_CLASS))).sum()
    fixed_order = rec.목_원자료.isin(FIX_ORDER).sum()
    rec_sites = out[out.벌레기록있음]
    print(f"목 오타·표기 고친 줄: {fixed_order}, 강 바로잡은 줄: {fixed_class}")
    print(f"벌레 기록 있는 조사지: {len(rec_sites)}곳 (없는 곳 {(~out.벌레기록있음).sum()}곳)")
    print(f"분석 대상: {int(used.개체수.sum()):,}마리, 조사 묶음: {rec_sites.조사묶음.value_counts().to_dict()}")


if __name__ == "__main__":
    main()
