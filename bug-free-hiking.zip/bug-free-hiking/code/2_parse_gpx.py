"""2단계: 100대 명산 GPX에서 산마다 정상 위치·고도와 코스 최저 고도를 뽑는다.

입력: data/raw_gpx/ 안에 공공데이터포털에서 받은 zip 파일을 그대로 두거나,
      압축을 푼 '100대명산/산이름/*.gpx' 폴더를 둔다.
      (한국등산트레킹지원센터_산림청 100대명산, https://www.data.go.kr/data/15098177/fileData.do)
출력: data/mountains_from_gpx.csv
- 정상 = 그 산 모든 코스의 경로점 중 가장 높은 점(GPS 고도라 실제 해발과 수십 m 차이 날 수 있음)
- 고도가 모두 0인 산(대암산)은 고도를 비워 둔다.
"""
import io
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict

import pandas as pd

from common import DATA

NS = "{http://www.topografix.com/GPX/1/1}"


def iter_gpx():
    """(산 이름, GPX 바이트)를 하나씩 돌려준다. zip과 폴더 모두 지원."""
    raw = DATA / "raw_gpx"
    for z in raw.glob("*.zip"):
        with zipfile.ZipFile(z) as zf:
            for info in zf.infolist():
                name = info.filename
                if not info.flag_bits & 0x800:  # 한글 파일 이름(cp949) 복원
                    try:
                        name = name.encode("cp437").decode("cp949")
                    except UnicodeError:
                        pass
                if name.lower().endswith(".gpx"):
                    yield name.split("/")[-2], zf.read(info)
    for f in raw.rglob("*.gpx"):
        yield f.parent.name, f.read_bytes()


def main():
    best, low, courses = {}, defaultdict(lambda: float("inf")), defaultdict(int)
    for mountain, blob in iter_gpx():
        courses[mountain] += 1
        root = ET.parse(io.BytesIO(blob)).getroot()
        for p in root.iter(NS + "trkpt"):
            e = p.findtext(NS + "ele")
            if not e:
                continue
            z = float(e)
            low[mountain] = min(low[mountain], z)
            if mountain not in best or z > best[mountain][0]:
                best[mountain] = (z, float(p.get("lat")), float(p.get("lon")))
    if not courses:
        print("data/raw_gpx/에 GPX가 없어 건너뜁니다. 저장소에 있는 data/mountains_from_gpx.csv를 그대로 씁니다.")
        return
    rows = []
    for m in sorted(courses):
        z, lat, lon = best[m]
        rows.append({"산": m, "코스수": courses[m],
                     "최고점_고도m": round(z, 1) if z > 0 else None,
                     "최고점_위도": lat, "최고점_경도": lon,
                     "코스_최저고도m": round(low[m], 1) if z > 0 else None})
    out = pd.DataFrame(rows)
    out.to_csv(DATA / "mountains_from_gpx.csv", index=False, encoding="utf-8-sig")
    print(f"산 {len(out)}개, 코스 {out.코스수.sum()}개, 고도 없는 산: {list(out[out.최고점_고도m.isna()].산)}")


if __name__ == "__main__":
    main()
