"""5단계: 결과 검증, 벌레 많은/적은 산의 특징 분석, Power BI용 표 만들기.

검증
- 재표집: 산마다 쓴 조사지를 복원추출로 1,000번 다시 뽑아 5위 안에 드는 비율
- 하나씩 빼기: 조사지를 하나씩 빼고 다시 계산했을 때의 순위 범위
- 기준 바꾸기: 반경·높이 범위·평균 대신 중앙값 등 6가지 기준에서 1~3위
- 조사 묶음 차이: 같은 도 안에서 묶음별 중앙값 비교, 환경·위치를 함께 넣은 회귀
- 피복도 착시 확인: 피복도와 거미 수의 관계를 전체 / 피복도 기록 있는 곳만 나눠 비교

특징
- 도별 점수, 강수량 구간별 점수, 환경 항목과 벌레 수의 순위상관
- 벌레가 적은 산 1/3과 많은 산 1/3의 환경 비교

출력: results/check_report.md, results/검증_기준바꾸기.csv, results/특징_*.csv, results/powerbi/*.csv
"""
import importlib

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import mannwhitneyu, spearmanr

from common import CLASSES, DATA, PROCESSED, RESULTS, TOTAL, pick_sites

match = importlib.import_module("4_match")
SEED, N_BOOT = 0, 1000
ENV = ["해발고도m", "평균기온", "강수량", "일사량", "경사", "식생지수"]
lines = []


def say(text=""):
    print(text)
    lines.append(text)


def bootstrap_top5(s, ok, col):
    idx = s.set_index("조사지번호")
    picks = {r.산: r.조사지번호들.split(",") for _, r in ok.iterrows()}
    rng = np.random.default_rng(SEED)
    hits = pd.Series(0, index=list(picks))
    for _ in range(N_BOOT):
        v = pd.Series({k: idx.loc[rng.choice(ids, len(ids), replace=True), col].mean()
                       for k, ids in picks.items()}).sort_values()
        hits[v.index[:5]] += 1
    return (hits / N_BOOT * 100).sort_values(ascending=False)


def leave_one_out(s, ok, col, name):
    idx = s.set_index("조사지번호")
    base = ok.set_index("산")[name]
    out = {}
    for _, r in ok.sort_values(name).head(5).iterrows():
        ids = r.조사지번호들.split(",")
        ranks = []
        for drop in ids:
            v = idx.loc[[i for i in ids if i != drop], col].mean()
            ranks.append(int((base.drop(r.산) < v).sum()) + 1)
        out[r.산] = (min(ranks), max(ranks))
    return out


def sensitivity(s, mountains):
    variants = [("지금 기준(30km, −150~+100m, 평균)", {}, "mean"),
                ("반경 20km", dict(r1=20, r2=40), "mean"),
                ("반경 40km", dict(r1=40, r2=60), "mean"),
                ("높이 범위 넓게(−300~+200m)", dict(below=300, above=200), "mean"),
                ("높이 범위 좁게(코스 높이대만)", dict(below=0, above=0), "mean"),
                ("평균 대신 중앙값", {}, "median")]
    rows = []
    for label, kw, agg in variants:
        res = {}
        for _, mt in mountains.iterrows():
            pk, _ = pick_sites(mt, s, **kw)
            if pk.거리km.mean() > 50:
                continue
            res[mt.산] = (getattr(pk[TOTAL + "_백분위"], agg)(), getattr(pk["거미강_백분위"], agg)())
        df = pd.DataFrame(res, index=["전체", "거미강"]).T
        rows.append({"기준": label,
                     "전체 1~3위": ", ".join(df.전체.sort_values().index[:3]),
                     "거미강 1~3위": ", ".join(df.거미강.sort_values().index[:3]),
                     "선운산 전체 순위": int(df.전체.rank(method="min")["선운산"]),
                     "선운산 거미강 순위": int(df.거미강.rank(method="min")["선운산"])})
    return pd.DataFrame(rows)


def main():
    s = match.load_sites()
    mountains = pd.read_csv(DATA / "mountains_from_gpx.csv")
    m = pd.read_csv(PROCESSED / "mountain_index.csv", dtype={"조사지번호들": str})
    ok = m[m.판단가능].copy()

    say("# 검증과 특징 분석 결과\n")
    say("## 1. 순위 검증")
    for col, name in [(TOTAL + "_백분위", "전체지수"), ("거미강_백분위", "거미강지수"), ("곤충강_백분위", "곤충강지수")]:
        top = bootstrap_top5(s, ok, col).head(5)
        say(f"- {name} 재표집 {N_BOOT}번, 5위 안 비율(%): " + ", ".join(f"{k} {v:.0f}" for k, v in top.items()))
        say(f"  - 조사지 하나씩 빼기, 상위 5곳 순위 범위: {leave_one_out(s, ok, col, name)}")
    sens = sensitivity(s, mountains)
    sens.to_csv(RESULTS / "검증_기준바꾸기.csv", index=False, encoding="utf-8-sig")
    say("\n기준을 바꿔 본 결과\n")
    say(sens.to_markdown(index=False))

    say("\n## 2. 조사 묶음 차이")
    say(f"- 묶음별 조사지 수: {s.조사묶음.value_counts().to_dict()}")
    by = s.groupby(["도", "조사묶음"])[["거미강", TOTAL]].median().unstack().round(0)
    say("- 같은 도 안 묶음별 중앙값(마리)\n")
    say(by.to_markdown())
    d = s.rename(columns={TOTAL: "total", "곤충강": "ins", "거미강": "spi", "지네강": "cen", "노래기강": "mil",
                          "갑각강": "cru", "해발고도m": "alt", "평균기온": "temp", "강수량": "rain",
                          "일사량": "sun", "경사": "slope", "식생지수": "ndvi", "위도": "lat", "경도": "lon"})
    d["batchB"] = d.조사묶음.str.startswith("B").astype(int)
    for v in ["alt", "temp", "rain", "sun", "slope", "ndvi", "lat", "lon"]:
        d[v + "_z"] = (d[v] - d[v].mean()) / d[v].std()
    say("\n- 회귀(로그 마릿수 ~ 묶음 + 표준화한 환경·위치), p<0.05인 항목만")
    for y in ["total", "ins", "spi", "cen", "mil", "cru"]:
        res = smf.ols(f"np.log1p({y}) ~ batchB + alt_z + temp_z + rain_z + sun_z + slope_z + ndvi_z + lat_z + lon_z",
                      data=d).fit()
        sig = {k: round(v, 2) for k, v in res.params.items() if k != "Intercept" and res.pvalues[k] < 0.05}
        say(f"  - {y}: R²={res.rsquared:.2f}, {sig}")

    say("\n## 3. 피복도 착시 확인(거미강과의 순위상관)")
    nz = s[s.조사묶음.str.startswith("A")]
    for c in ["낙엽피복도", "관목피복도", "초본피복도"]:
        r_all, p_all = spearmanr(s[c], s.거미강)
        r_nz, p_nz = spearmanr(nz[c], nz.거미강)
        say(f"- {c}: 전체 262곳 {r_all:+.2f}(p={p_all:.3g}), 피복도 기록 있는 {len(nz)}곳 {r_nz:+.2f}(p={p_nz:.3g})")

    say("\n## 4. 특징")
    prov = (s.groupby("도").agg(조사지수=("조사지번호", "size"), 점수중앙값=(TOTAL + "_백분위", "median"),
                              강수량중앙값mm=("강수량", "median")).reset_index())
    prov = prov[prov.조사지수 >= 5].sort_values("점수중앙값").round(0)
    prov.to_csv(RESULTS / "특징_도별_점수.csv", index=False, encoding="utf-8-sig")
    say("- 도별 점수(조사지 5곳 이상)\n")
    say(prov.to_markdown(index=False))
    s["강수량구간"] = pd.qcut(s.강수량, 3, labels=["적음", "중간", "많음"])
    rain = (s.groupby("강수량구간", observed=True).agg(조사지수=("조사지번호", "size"),
            강수량중앙값mm=("강수량", "median"), 점수중앙값=(TOTAL + "_백분위", "median")).reset_index().round(0))
    rain.to_csv(RESULTS / "특징_강수량별_점수.csv", index=False, encoding="utf-8-sig")
    say("\n- 강수량 구간별 점수\n")
    say(rain.to_markdown(index=False))
    say("\n- 환경 항목과 마릿수의 순위상관(262곳, 묶음 구분 없음)")
    for e in ENV:
        out = []
        for t in [TOTAL, "곤충강", "거미강"]:
            r, p = spearmanr(s[e], s[t])
            out.append(f"{t} {r:+.2f}{'*' if p < 0.01 else ''}")
        say(f"  - {e}: " + ", ".join(out))

    site_env = s.set_index("조사지번호")
    ok["지역"] = ok.조사지번호들.map(lambda x: site_env.loc[x.split(","), "도"].mode().iat[0])
    for e in ENV:
        ok[e] = ok.조사지번호들.map(lambda x, e=e: site_env.loc[x.split(","), e].mean())
    ok = ok.sort_values("전체지수")
    n = len(ok) // 3
    lo, hi = ok.head(n), ok.tail(n)
    comp = []
    for c in ["정상고도m", "위도", "경도"] + ENV:
        comp.append({"특징": c, "적은 산 중앙값": round(lo[c].median(), 1), "많은 산 중앙값": round(hi[c].median(), 1),
                     "p(맨-휘트니)": round(mannwhitneyu(lo[c].dropna(), hi[c].dropna()).pvalue, 3)})
    comp = pd.DataFrame(comp)
    comp.to_csv(RESULTS / "특징_적은산_vs_많은산.csv", index=False, encoding="utf-8-sig")
    say(f"\n- 벌레 적은 산 {n}곳 vs 많은 산 {n}곳(근처 조사지 평균)\n")
    say(comp.to_markdown(index=False))
    say(f"\n- 적은 10곳 지역: {ok.head(10)[['산', '지역']].values.tolist()}")
    say(f"- 많은 10곳 지역: {ok.tail(10)[['산', '지역']].values.tolist()}")

    # Power BI용 표
    pbi = RESULTS / "powerbi"
    pbi.mkdir(parents=True, exist_ok=True)
    rows = []
    for _, r in m.iterrows():
        for c in ["전체"] + CLASSES:
            rows.append({"산": r.산, "위도": r.위도, "경도": r.경도, "정상고도m": r.정상고도m, "분류": c,
                         "지수": r["전체지수"] if c == "전체" else r[c + "지수"],
                         "조사지당마릿수": round(r[(TOTAL if c == "전체" else c) + "_평균"], 1),
                         "쓴조사지수": r.조사지수, "판단가능": "예" if r.판단가능 else "아니요(섬)"})
    pd.DataFrame(rows).to_csv(pbi / "1_산별_지수.csv", index=False, encoding="utf-8-sig")
    prov.to_csv(pbi / "2_도별_점수.csv", index=False, encoding="utf-8-sig")
    tot = s[CLASSES].sum()
    share = pd.DataFrame({"분류": CLASSES, "마릿수": tot.values})
    share["비율%"] = (share.마릿수 / share.마릿수.sum() * 100).round(1)
    share.to_csv(pbi / "3_강별_비율.csv", index=False, encoding="utf-8-sig")
    rain.to_csv(pbi / "4_강수량별_점수.csv", index=False, encoding="utf-8-sig")
    s[["조사지번호", "조사지명", "도", "위도", "경도", "해발고도m", "강수량", "조사묶음", TOTAL] + CLASSES
      + [TOTAL + "_백분위"]].rename(columns={TOTAL: "전체마릿수", TOTAL + "_백분위": "묶음내점수"}).to_csv(
        pbi / "5_조사지.csv", index=False, encoding="utf-8-sig")

    (RESULTS / "check_report.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
