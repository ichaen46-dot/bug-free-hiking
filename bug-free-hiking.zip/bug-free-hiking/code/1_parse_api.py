"""1단계: 공공데이터포털에서 저장한 API 결과(XML)를 CSV로 바꾼다.

입력: data/raw_api/*.xml
  - 절지동물분포 조사지역 정보(조사지 366곳) 결과
  - 절지동물분포 임상별 조사자료(벌레 기록 5,517줄, 1,000줄씩 6페이지) 결과
  파일 이름은 상관없다. 항목을 보고 어느 기능의 결과인지 구분한다.
출력: data/sites_raw.csv, data/records_raw.csv (원래 항목 이름 그대로)
"""
import xml.etree.ElementTree as ET

import pandas as pd

from common import DATA


def read_items(path):
    root = ET.parse(path).getroot()
    code = root.findtext("header/resultCode")
    if code != "00":
        raise ValueError(f"{path.name}: 정상 응답이 아님(resultCode={code})")
    items = [{c.tag: c.text for c in it} for it in root.iter("item")]
    return items, int(root.findtext("body/pageNo")), int(root.findtext("body/totalCount"))


def main():
    sites, records, totals = [], [], {}
    for path in sorted((DATA / "raw_api").glob("*.xml")):
        items, page, total = read_items(path)
        if not items:
            continue
        kind = "sites" if "avrgTmprt" in items[0] else "records"
        (sites if kind == "sites" else records).extend(items)
        totals.setdefault(kind, total)
        print(f"{path.name}: {kind}, page {page}, {len(items)}줄 (전체 {total})")

    s = pd.DataFrame(sites).drop_duplicates("nwSrznNo")
    r = pd.DataFrame(records)
    r["totPplti"] = pd.to_numeric(r.totPplti)
    # 빠진 페이지가 없는지 확인
    assert len(s) == totals["sites"], f"조사지 수 불일치: {len(s)} vs {totals['sites']}"
    assert len(r) == totals["records"], f"기록 수 불일치: {len(r)} vs {totals['records']}"

    s.to_csv(DATA / "sites_raw.csv", index=False, encoding="utf-8-sig")
    r.to_csv(DATA / "records_raw.csv", index=False, encoding="utf-8-sig")
    print(f"조사지 {len(s)}곳, 벌레 기록 {len(r)}줄, {int(r.totPplti.sum()):,}마리")


if __name__ == "__main__":
    main()
