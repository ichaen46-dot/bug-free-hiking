"""4단계: 100대 명산과 가까운 조사지를 이어 산별 벌레 지수를 계산한다.

산과 조사지 잇기
- 정상에서 반경 30km 안, 해발고도가 '코스 최저점 −150m ~ 정상 +100m'인 조사지
- 3곳이 안 되면 50km로 넓히고, 그래도 안 되면 높이 조건을 빼고, 마지막엔 가장 가까운 3곳
- 쓴 조사지의 평균 거리가 50km를 넘으면(섬) 판단 불가로 비교에서 뺀다.

벌레 지수(0~100, 낮을수록 벌레가 적게 기록됨)
- 조사지마다 같은 조사 묶음 안에서의 백분위를 구한다.
  백분위 = (묶음 안에서 그 조사지보다 적은 곳 수 + 같은 곳 수 × 0.5) ÷ 묶음 조사지 수 × 100
- 산의 지수 = 그 산에 쓴 조사지 백분위의 평균
- 전체(분석 대상)와 5개 강(곤충·거미·지네·노래기·갑각)마다 따로 계산한다.

입력: data/processed/sites_with_bugs.csv, data/mountains_from_gpx.csv
출력: results/100대명산_벌레지수.csv, data/processed/sites_scored.csv, data/processed/mountain_index.csv
"""
import numpy as np
import pandas as pd

from common import (CLASSES, DATA, MAX_MEAN_DIST_KM, PROCESSED, RESULTS, TOTAL,
                    batch_percentiles, pick_sites)

READABLE = {
    "산": "산", "정상고도m": "정상고도(m, GPS)", "맞춤방식": "조사지 맞춤 방식", "조사지수": "쓴 조사지 수",
    "평균거리km": "정상까지 평균 거리(km)", "B묶음비율": "피복도 없는 묶음 조사지 비율",
    TOTAL + "_평균": "조사지당 전체(마리)", "전체지수": "전체 지수(0~100, 낮을수록 적음)",
    **{f"{c}_평균": f"{c}(마리)" for c in CLASSES}, **{f"{c}지수": f"{c} 지수" for c in CLASSES},
    "판단가능": "판단 가능(50km 안 기록)"}


def load_sites():
    s = pd.read_csv(PROCESSED / "sites_with_bugs.csv", dtype={"조사지번호": str})
    s = s[s.벌레기록있음].copy()
    for c in [TOTAL] + CLASSES:
        s[c + "_백분위"] = batch_percentiles(s, c)
    return s


def score_mountains(s, mountains, **pick_kw):
    rows = []
    for _, mt in mountains.iterrows():
        pick, how = pick_sites(mt, s, **pick_kw)
        r = {"산": mt.산, "정상고도m": mt.최고점_고도m, "코스최저고도m": mt.코스_최저고도m,
             "위도": mt.최고점_위도, "경도": mt.최고점_경도, "맞춤방식": how, "조사지수": len(pick),
             "평균거리km": pick.거리km.mean(), "조사지번호들": ",".join(pick.조사지번호),
             "조사지평균고도m": pick.해발고도m.mean(), "B묶음비율": pick.조사묶음.str.startswith("B").mean()}
        for c in [TOTAL] + CLASSES:
            r[c + "_평균"] = pick[c].mean()
            r["전체지수" if c == TOTAL else c + "지수"] = pick[c + "_백분위"].mean()
        rows.append(r)
    out = pd.DataFrame(rows)
    out["판단가능"] = out.평균거리km <= MAX_MEAN_DIST_KM
    idx_cols = ["전체지수"] + [c + "지수" for c in CLASSES]
    out.loc[~out.판단가능, idx_cols] = np.nan
    return out


def main():
    s = load_sites()
    m = pd.read_csv(DATA / "mountains_from_gpx.csv")
    out = score_mountains(s, m)
    num = out.select_dtypes("number").columns
    out[num] = out[num].round(1)
    out = out.sort_values("전체지수")

    PROCESSED.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    out.to_csv(PROCESSED / "mountain_index.csv", index=False, encoding="utf-8-sig")
    s.to_csv(PROCESSED / "sites_scored.csv", index=False, encoding="utf-8-sig")
    readable = out[list(READABLE)].rename(columns=READABLE)
    readable["판단 가능(50km 안 기록)"] = readable["판단 가능(50km 안 기록)"].map({True: "예", False: "아니요(섬)"})
    readable.to_csv(RESULTS / "100대명산_벌레지수.csv", index=False, encoding="utf-8-sig")

    ok = out[out.판단가능]
    print(f"비교한 산: {len(ok)}곳 (판단 불가: {list(out[~out.판단가능].산)})")
    for name in ["전체지수", "곤충강지수", "거미강지수"]:
        top = ok.sort_values(name).head(5)
        print(name, "적은 산:", ", ".join(f"{a} {b:.1f}" for a, b in zip(top.산, top[name])))
    print("전체가 많은 산:", list(ok.sort_values("전체지수").산.tail(3)))


if __name__ == "__main__":
    main()
